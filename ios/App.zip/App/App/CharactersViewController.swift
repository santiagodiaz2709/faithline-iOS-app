import UIKit
import WebKit

class CharactersViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler {

    var webView: WKWebView!
    var loader: UIActivityIndicatorView!
    var urlObservation: NSKeyValueObservation?

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemBackground
        title = "Characters"

        let config = WKWebViewConfiguration()
        let userContentController = WKUserContentController()
        config.userContentController = userContentController

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        loader = UIActivityIndicatorView(style: .large)
        loader.translatesAutoresizingMaskIntoConstraints = false
        loader.startAnimating()
        view.addSubview(loader)

        NSLayoutConstraint.activate([
            loader.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loader.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])

        setupRouteTracking()
        observeWebViewURL()

        if let url = URL(string: "https://faithline.pro/characters") {
            webView.load(URLRequest(url: url))
        }
    }

    deinit {
        urlObservation?.invalidate()
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "routeChanged")
    }

    private func setupRouteTracking() {
        let controller = webView.configuration.userContentController
        controller.removeScriptMessageHandler(forName: "routeChanged")
        controller.add(self, name: "routeChanged")

        let script = """
        (function() {
            if (window.__iosRouteTrackingInstalled) return;
            window.__iosRouteTrackingInstalled = true;

            function notifyRouteChange() {
                try {
                    window.webkit.messageHandlers.routeChanged.postMessage(window.location.href);
                } catch (e) {
                    console.log("routeChanged error", e);
                }
            }

            const originalPushState = history.pushState;
            history.pushState = function() {
                originalPushState.apply(history, arguments);
                setTimeout(notifyRouteChange, 0);
            };

            const originalReplaceState = history.replaceState;
            history.replaceState = function() {
                originalReplaceState.apply(history, arguments);
                setTimeout(notifyRouteChange, 0);
            };

            window.addEventListener('popstate', function() {
                setTimeout(notifyRouteChange, 0);
            });

            window.addEventListener('hashchange', function() {
                setTimeout(notifyRouteChange, 0);
            });

            document.addEventListener('click', function() {
                setTimeout(notifyRouteChange, 300);
            }, true);

            setTimeout(notifyRouteChange, 0);
            setTimeout(notifyRouteChange, 500);
            setTimeout(notifyRouteChange, 1200);
        })();
        """

        let userScript = WKUserScript(
            source: script,
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: false
        )

        controller.addUserScript(userScript)
    }

    private func observeWebViewURL() {
        urlObservation = webView.observe(\.url, options: [.new, .initial]) { [weak self] webView, _ in
            guard let self = self else { return }
            if let currentURL = webView.url?.absoluteString {
                print("Characters KVO URL: \(currentURL)")
                NotificationCenter.default.post(name: .didUpdateCurrentWebURL, object: currentURL)
            }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "routeChanged",
           let currentURL = message.body as? String {
            print("Characters JS URL: \(currentURL)")
            NotificationCenter.default.post(name: .didUpdateCurrentWebURL, object: currentURL)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        loader.startAnimating()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loader.stopAnimating()

        if let currentURL = webView.url?.absoluteString {
            print("Characters didFinish URL: \(currentURL)")
            NotificationCenter.default.post(name: .didUpdateCurrentWebURL, object: currentURL)
        }

        webView.evaluateJavaScript("window.location.href") { result, _ in
            if let currentURL = result as? String {
                print("Characters eval JS URL: \(currentURL)")
                NotificationCenter.default.post(name: .didUpdateCurrentWebURL, object: currentURL)
            }
        }
    }

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {

        if let currentURL = navigationAction.request.url?.absoluteString {
            print("Characters navigationAction URL: \(currentURL)")
            NotificationCenter.default.post(name: .didUpdateCurrentWebURL, object: currentURL)
        }

        decisionHandler(.allow)
    }
}
